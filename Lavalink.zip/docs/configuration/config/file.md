---
description: How to configure Lavalink with the Config File
---

# Config File

The server configuration is done in `application.yml`. You can find an example below.

## Example application.yml

```yaml title="application.yml"
--8<-- "LavalinkServer/application.yml.example"
```
