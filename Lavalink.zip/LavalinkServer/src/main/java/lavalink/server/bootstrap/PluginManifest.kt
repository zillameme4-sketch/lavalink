package lavalink.server.bootstrap

data class PluginManifest(
    val name: String,
    val path: String,
    val version: String
)